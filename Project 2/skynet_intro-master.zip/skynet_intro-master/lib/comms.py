import struct

from Crypto.Hash import HMAC
from Crypto.Cipher import AES
import time
from dh import create_dh_key, calculate_dh_secret


class StealthConn(object):
    def __init__(self, conn, client=False, server=False, verbose=False):
        self.conn = conn
        self.cipher = None
        self.client = client
        self.server = server
        self.verbose = verbose
        self.shared_hash = None
        self.hmac = None
        self.initiate_session()

    def initiate_session(self):
        if self.server or self.client:
            my_public_key, my_private_key = create_dh_key()
            # Send them our public key
            self.send(bytes(str(my_public_key), "ascii"))
            # Receive their public key
            their_public_key = int(self.recv())
            # Obtain our shared secret
            self.shared_hash = calculate_dh_secret(their_public_key, my_private_key)
            print("Shared hash: {}".format(self.shared_hash))

        # Key of AES
        key = bytes.fromhex(self.shared_hash)
        # initialisation vector is previous 16 bytes shared_hash
        iv = self.shared_hash[:16]
        # Create AES object with CFB mode
        self.cipher = AES.new(key, AES.MODE_CFB, iv)
        # Create HMAC
        self.hmac = HMAC.new(bytes(self.shared_hash[:64], encoding='ascii'), None)

    def send(self, data):
        if self.cipher:
            # encrypt data
            encrypted_data = self.cipher.encrypt(data)
            original = data

            # calculate hmac
            self.hmac.update(encrypted_data)
            message_hmac = self.hmac.hexdigest().encode()
            # append hmac to the end
            encrypted_data = encrypted_data + message_hmac

            if self.verbose:
                print("Original data: {}".format(original))
                print("Encrypted data: {}".format(repr(encrypted_data)))
                print("Sending packet of length {}".format(len(encrypted_data)))
        else:
            encrypted_data = data

        # Encode the timestamp
        time_now = int(round(time.time() * 1000))
        pkt_len = struct.pack('q',  time_now)
        self.conn.sendall(pkt_len)

        # Encode the data's length into an unsigned two byte int ('H')
        pkt_len = struct.pack('H', len(encrypted_data))
        self.conn.sendall(pkt_len)
        self.conn.sendall(encrypted_data)

    def recv(self):
        # Decode the timestamp
        time_received = self.conn.recv(struct.calcsize('q'))
        time_received = struct.unpack('q', time_received)
        time_now = int(round(time.time() * 1000))
        # compare timestamp, if larger than half second then it is a invalid data (replay attack)
        time_gap = time_now - time_received[0]
        if int(time_gap) > 500 or int(time_gap) < -500:
            print("Received packet is invalid")

        # Decode the data's length from an unsigned two byte int ('H')
        pkt_len_packed = self.conn.recv(struct.calcsize('H'))
        unpacked_contents = struct.unpack('H', pkt_len_packed)
        pkt_len = unpacked_contents[0]
        encrypted_data = self.conn.recv(pkt_len)

        if self.cipher:
            # the received HMAC
            # receive_hmac = encrypted_data[16:]
            receive_hmac = encrypted_data[pkt_len - 32:pkt_len]
            self.hmac.update(encrypted_data[:pkt_len - 32])
            # get the original HMAC
            original_hmac = self.hmac.hexdigest().encode()
            # check whether original HMAC equals to received HMAC
            if receive_hmac != original_hmac:
                print("Tampering Attack!! closing connection.")

            data = self.cipher.decrypt(encrypted_data[:-32])

            if self.verbose:
                print("Receiving packet of length {}".format(pkt_len))
                print("Encrypted data: {}".format(repr(encrypted_data)))
                print("Original data: {}".format(data))
        else:
            data = encrypted_data

        return data

    def close(self):
        self.conn.close()
